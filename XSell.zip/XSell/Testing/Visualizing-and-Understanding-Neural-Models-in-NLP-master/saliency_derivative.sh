python util/StringToNum.py data/dict.txt input.txt util/input_index.txt
th saliency_derivative.lua
python heatmap.py
