python util/StringToNum.py data/dict.txt input.txt util/input_index.txt
~/torch/install/bin/th saliency_variance.lua
python heatmap.py
