# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestModelController(BaseTestCase):
    """ModelController integration test stubs"""

    def test_add_model(self):
        """Test case for add_model

        Add a new model
        """
        response = self.client.open(
            '/JustinHandsmanXSell/XSell/1.0.0/model/{id}'.format(id=56),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_model(self):
        """Test case for delete_model

        Deletes a model
        """
        headers = [('api_key', 'api_key_example')]
        response = self.client.open(
            '/JustinHandsmanXSell/XSell/1.0.0/model/{id}'.format(id=789),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_model_by_id(self):
        """Test case for get_model_by_id

        Find model by ID
        """
        response = self.client.open(
            '/JustinHandsmanXSell/XSell/1.0.0/model/{id}'.format(id=789),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_model(self):
        """Test case for update_model

        Update an existing model
        """
        response = self.client.open(
            '/JustinHandsmanXSell/XSell/1.0.0/model/{id}'.format(id=56),
            method='PUT',
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
