import connexion
import six

from swagger_server import util


def add_model(id):  # noqa: E501
    """Add a new model

     # noqa: E501

    :param id: model object
    :type id: int

    :rtype: None
    """
    return 'do some magic!'


def delete_model(id, api_key=None):  # noqa: E501
    """Deletes a model

     # noqa: E501

    :param id: Model id to delete
    :type id: int
    :param api_key: 
    :type api_key: str

    :rtype: None
    """
    return 'do some magic!'


def get_model_by_id(id):  # noqa: E501
    """Find model by ID

    Returns a single model # noqa: E501

    :param id: ID of model to return
    :type id: int

    :rtype: None
    """
    return 'do some magic!'


def update_model(id):  # noqa: E501
    """Update an existing model

     # noqa: E501

    :param id: model object that needs to be added to the store
    :type id: int

    :rtype: None
    """
    return 'do some magic!'
