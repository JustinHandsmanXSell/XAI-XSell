import connexion
import six

from swagger_server import util


def create_user(userid):  # noqa: E501
    """Create user

    This can only be done by the logged in user. # noqa: E501

    :param userid: Created user object
    :type userid: int

    :rtype: None
    """
    return 'do some magic!'


def delete_user(userid):  # noqa: E501
    """Delete user

    This can only be done by the logged in user. # noqa: E501

    :param userid: The name that needs to be deleted
    :type userid: str

    :rtype: None
    """
    return 'do some magic!'


def get_user_by_name(userid):  # noqa: E501
    """Get user by user id

     # noqa: E501

    :param userid: The name that needs to be fetched. Use user1 for testing. 
    :type userid: str

    :rtype: None
    """
    return 'do some magic!'


def login_user(username, password):  # noqa: E501
    """Logs user into the system

     # noqa: E501

    :param username: The user name for login
    :type username: str
    :param password: The password for login in clear text
    :type password: str

    :rtype: str
    """
    return 'do some magic!'


def logout_user():  # noqa: E501
    """Logs out current logged in user session

     # noqa: E501


    :rtype: None
    """
    return 'do some magic!'


def update_user(userid):  # noqa: E501
    """Updated user

    This can only be done by the logged in user. # noqa: E501

    :param userid: name that need to be updated
    :type userid: int

    :rtype: None
    """
    return 'do some magic!'
