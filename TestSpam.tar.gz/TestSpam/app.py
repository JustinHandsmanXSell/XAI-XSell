#load the required libraries
import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score, f1_score
import streamlit as st
import os
import pickle

@st.cache
def load_data():
	#read the data
	df = pd.read_csv('SMSSpamCollection.txt', 			delimiter='\t',header=None)
	df.rename(columns = {0:'label',1: 'text'}, inplace = True)
	#Input and output variables
	X = df['text']
	y = df['label']
	return df, X, y

df, X, y = load_data()

st.title("Spam Prediction and Text Explainer")

models = st.sidebar.selectbox('Choose Model', ['Spam Logistic Regression', 'Spam Neural Net'])
if models == 'Spam Logistic Regression':
	pipe = pickle.load(open("spam_model.sav", "rb"))
	scores = pd.read_csv("scores1.csv")
elif models == 'Spam Neural Net':
	pipe = pickle.load(open("spam_model2.sav", "rb"))
	scores = pd.read_csv("scores2.csv")


'You Selected: ', models

selectData = st.selectbox('Input Data or Use Test Data',['Input','Test'])

if selectData == 'Input':
	doc = st.text_input("Enter Text")
elif selectData == 'Test':
	d = pd.read_csv('testData.csv')
	sampleText = st.selectbox('Sample Spam or Not Spam', ['Spam','Not Spam'])
	if sampleText == 'Spam':
		sampleSpam = st.text("Dear Voucher Holder, To claim this weeks offer, at you PC please go to http://www.e-tlp.co.uk/expressoffer Ts&Cs apply. To stop texts, txt STOP to 80062")
		doc = "Dear Voucher Holder, To claim this weeks offer, at you PC please go to http://www.e-tlp.co.uk/expressoffer Ts&Cs apply. To stop texts, txt STOP to 80062"
	else:
		sampleNotSpam = st.text("Yo carlos, a few friends are already asking me about you, you working at all this weekend?")
		doc = "Yo carlos, a few friends are already asking me about you, you working at all this weekend?"

def print_prediction(doc, cat):
    y_pred = pipe.predict_proba([doc])[0]
    cate = []
    perc = []
    for target, prob in zip(cat, y_pred):
        cate.append(prob)
        perc.append(target)
    return cate, perc

st.write(scores)

try:
    if st.checkbox('Show Raw Data'):
        st.subheader('Raw Data')
        st.write(df)
    y = pipe.predict([doc])[0]
    if y == 'ham':
        cat = ['Spam', 'Not Spam']
    else:
        cat = ['Not Spam', 'Spam']
    from lime.lime_text import LimeTextExplainer
    explainer = LimeTextExplainer(class_names = cat)

    exp = explainer.explain_instance(doc, pipe.predict_proba)
    st.write(exp.as_pyplot_figure())
    b = ['Not Spam', 'Spam']
    c, f = print_prediction(doc, b)
    df = pd.DataFrame(c,f)
    df.columns = ['Probability']
    st.write(df)
except:
    st.write("Invalid or Blank Input")
