seed = 5
test_size = 0.33

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pandas as pd
import pickle

def load_data():
	#read the data
	df = pd.read_csv('SMSSpamCollection.txt', 			delimiter='\t',header=None)
	df.rename(columns = {0:'label',1: 'text'}, inplace = True)
	#Input and output variables
	X = df['text']
	y = df['label']
	return df, X, y

df, X, y = load_data()

#Convert to a matrix of TF-IDF features
from sklearn.decomposition import TruncatedSVD
from sklearn.pipeline import Pipeline, make_pipeline
from sklearn.linear_model import LogisticRegression
vec = TfidfVectorizer()
svd = TruncatedSVD(n_components=100,n_iter=7,random_state = seed)
lsa = make_pipeline(vec,svd)
#Model training
classifier = MLPClassifier(alpha=1, max_iter=1000)
pipe = make_pipeline(lsa, classifier)

x_train, x_test, y_train, y_test = train_test_split(X, y, test_size = test_size, random_state=seed)
pipe.fit(x_train, y_train)
pipe.score(x_test, y_test)

d = {}
x_t = list(x_test)
y_t = list(y_test)
for i in range(0,len(x_test)):
	x = x_t[i]
	y = y_t[i]
	d[x] = y
k = []
v = []
for key,value in d.items():
	k.append(key)
	v.append(value)


test_file = pd.DataFrame(v,k)
test_file.columns = ['Class']
test_file.to_csv("testData.csv")

y_pred = pipe.predict(x_test)
print(accuracy_score(y_test, y_pred))

y_pred = pipe.predict(x_test)
from sklearn.metrics import accuracy_score, f1_score
acc = ['F-Score', 'Accuracy']
f1 = [f1_score(y_test, y_pred, average='weighted'), accuracy_score(y_test, y_pred)]
scores = pd.DataFrame(f1, acc)
scores.columns = ['Score']
scores.to_csv("scores2.csv")

filename = 'spam_model2.sav'
pickle.dump(pipe,open(filename,'wb'))


