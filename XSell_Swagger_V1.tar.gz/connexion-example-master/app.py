#!/usr/bin/env python3
import connexion
import datetime
import logging

from connexion import NoContent

# our memory-only pet storage
MODELS = {}


def get_models(limit):
    return {"models": [model for model in MODELS.values()]}


def get_model(model_id):
    model = Models.get(model_id)
    return model or ('Not found', 404)


def put_model(model_id, model):
    exists = model_id in MODELS
    model['id'] = model_id
    if exists:
        logging.info('Updating model %s..', model_id)
        MODELS[model_id].update(model)
    else:
        logging.info('Creating model %s..', model_id)
        model['created'] = datetime.datetime.utcnow()
        MODELS[model_id] = model
    return NoContent, (200 if exists else 201)


def delete_model(model_id):
    if model_id in MODELS:
        logging.info('Deleting model %s..', model_id)
        del MODELS[model_id]
        return NoContent, 204
    else:
        return NoContent, 404


logging.basicConfig(level=logging.INFO)
app = connexion.App(__name__)
app.add_api('swagger.yaml')
# set the WSGI application callable to allow using uWSGI:
# uwsgi --http :8080 -w app
application = app.app

if __name__ == '__main__':
    # run our standalone gevent server
    app.run(port=8080, server='gevent')
