from model import NLPModel
import pandas as pd
from sklearn.model_selection import train_test_split

model = NLPModel()

def load_data():
    #read the data
    df = pd.read_csv('SMSSpamCollection.txt', delimiter='\t',header=None)
    df.rename(columns = {0:'label',1: 'text'}, inplace = True)
    #Input and output variables
    X = df['text']
    y = df['label']
    return df, X, y

df, X, y = load_data()

model.vectorizer_fit(X)

X = model.vectorizer_transform(X)

x_train, x_test, y_train, y_test = train_test_split(X, y, test_size = 0.33)

model.train(x_train, y_train)

model.pickle_clf()

model.pickle_vectorizer()




