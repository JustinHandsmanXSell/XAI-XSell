from fastapi import FastAPI
from pydantic import BaseModel
import pickle
import numpy as np
from model import NLPModel
import lime
import sklearn
from fastapi.openapi.utils import get_openapi


model = NLPModel()

class Models(BaseModel):
    model_id: int
    name: str
    description: str = None
    clf_pkl: str

        
vec_path = 'TFIDFVectorizer.pkl'
with open(vec_path, 'rb') as f:
    model.vectorizer = pickle.load(f)

models = {1:['Spam Classification', 'Neural Net, MLPClassifier', 'classifier.pkl']}
explainers = {1:['Lime']}

app = FastAPI()

@app.get("/predict/{model_id}/{explainer_id}/{text}")
def get_pred(text: str, model_id: int, explainer_id:int):
    if model_id in models.keys() and explainer_id == 1:
        
        clf_path = models[model_id][2]
        
        with open(clf_path, 'rb') as f:
            model.clf = pickle.load(f)
        
        uq = np.array([text])
        uq_vectorized = model.vectorizer_transform(uq)
        prediction = model.predict(uq_vectorized)
        pred_proba = model.predict_proba(uq_vectorized)
    
        # Output either 'Negative' or 'Positive' along with the score
        if prediction == 'spam':
            pred_text = 'Spam'
        else:
            pred_text = 'Not Spam'

        
        # round the predict proba value and set to new variable
        confidence = round(pred_proba[0], 3)

        #Lime
        from sklearn.pipeline import make_pipeline
        c = make_pipeline(model.vectorizer, model.clf)

        from lime.lime_text import LimeTextExplainer
        explainer = LimeTextExplainer()
        exp = explainer.explain_instance(text, c.predict_proba)
        expOutput = exp.as_list()
        d = {}
        for i in expOutput:
            for j in i:
                d[i[0]] = i[1]

        # create JSON object
        output = {'prediction': pred_text, 'confidence': confidence, 'Lime': d}
    
        return output
    else:
        return "404 Not Found"
    
    
@app.get("/model/{model_id}")
def get_model(model_id: int):
    if model_id in models.keys():
        return models[model_id]
    else:
        return "404 Not Found"
    
@app.get("/model")
def get_all_models():
    return models
    
@app.get("/explainer/{explainer_id}")
def get_explainer(explainer_id:int):
    if explainer_id in explainers.keys():
        return explainers[explainer_id]
    else:
        return "404 Not Found"    

@app.get("/explainer")
def get_all_explainers():
    return explainers

@app.post("/model")
def create_model(model:Models):
    models[model.model_id] = [model.name, model.description, model.clf_pkl]
    return models

@app.delete("/model/{model_id}")
def delete_model(model_id:int):
    if model_id in models[model.model_id]:
        del models[model_id]
        return models
    else:
        return "404 Not Found"

def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="XSell eXplanable AI Practicum Project",
        version="1",
        description="By Justin Handsman",
        routes=app.routes,
    )
    openapi_schema["info"]["x-logo"] = {
        "url": "https://fastapi.tiangolo.com/img/logo-margin/logo-teal.png"
    }
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi
