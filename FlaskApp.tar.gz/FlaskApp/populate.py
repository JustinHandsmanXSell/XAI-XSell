from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Let's import our Book and Base classes from our database_setup.py file
from database_setup import User, Base

# bind the engine to the metadata of the Base class so that the
# declaratives can be accessed through a DBSession instance
engine = create_engine('sqlite:///userdata.db')
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
# A DBSession() instance establishes all conversations with the database
# and represents a "staging zone" for all the objects loaded into the
# database session object.
session = DBSession()

# Create

userOne = User(Fname="Justin", Lname="Handsman", passw="test")
session.add(userOne)
session.commit()

# Read

session.query(User).all()
session.query(User).first()

# Update
editedUser = session.query(User).filter_by(id=1).one()
editedUser.passw = "test1"
session.add(editedUser)
session.commit()

# Delete

userToDelete = session.query(User).filter_by(Fname='Justin').one()
session.delete(userToDelete)
session.commit()
