from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database_setup import Base, User

# Connect to Database and create database session
engine = create_engine('sqlite:///userdata.db')
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()


# landing page that will display all the Users in our database
# This function operate on the Read operation.
@app.route('/')
@app.route('/Users')
def showUsers():
    Users = session.query(User).all()
    return render_template("Users.html", Users=Users)


# This will let us Create a new User and save it in our database
@app.route('/Users/new/', methods=['GET', 'POST'])
def newUser():
    if request.method == 'POST':
        newUser = User(Fname=request.form['Fname'], Lname=request.form['Lname'], passw=request.form['passw'])
        session.add(newUser)
        session.commit()
        return redirect(url_for('showUsers'))
    else:
        return render_template('newUser.html')


# This will let us Update our Users and save it in our database
@app.route("/Users/<int:User_id>/edit/", methods=['GET', 'POST'])
def editUser(User_id):
    editedUser = session.query(User).filter_by(id=User_id).one()
    if request.method == 'POST':
        if request.form['Fname']:
            editedUser.Fname = request.form['Fname']
            return redirect(url_for('showUsers'))
    else:
        return render_template('editUser.html', User=editedUser)


# This will let us Delete our User
@app.route('/Users/<int:User_id>/delete/', methods=['GET', 'POST'])
def deleteUser(User_id):
    UserToDelete = session.query(User).filter_by(id=User_id).one()
    if request.method == 'POST':
        session.delete(UserToDelete)
        session.commit()
        return redirect(url_for('showUsers', User_id=User_id))
    else:
        return render_template('deleteUser.html', User=UserToDelete)


if __name__ == '__main__':
    app.debug = True
    app.run(host='0.0.0.0', port=4896)
